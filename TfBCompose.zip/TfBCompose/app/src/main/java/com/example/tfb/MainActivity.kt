package com.example.tfb

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import com.example.tfb.ui.theme.TfBTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TfBTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    Greeting("TfB")
                }
            }
        }
    }
}
